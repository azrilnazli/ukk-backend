<?php 
phpinfo(); // system environment 

